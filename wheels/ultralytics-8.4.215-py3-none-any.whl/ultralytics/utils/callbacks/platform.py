# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

import os
import platform
import re
import socket
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from math import isfinite
from pathlib import Path, PureWindowsPath
from time import time

from ultralytics.utils import (
    ENVIRONMENT,
    GIT,
    LOGGER,
    PLATFORM_URL,
    PYTHON_VERSION,
    SETTINGS,
    TESTS_RUNNING,
    colorstr,
)

PREFIX = colorstr("Platform: ")
_api_key = None
_executor = ThreadPoolExecutor(max_workers=10)


def slugify(text):
    """Convert text to URL-safe slug (e.g., 'My Project 1' -> 'my-project-1')."""
    if not text:
        return text
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9\s-]", "", str(text).lower()).replace(" ", "-")).strip("-")[:128]


def _compact_plot(plot, n=101):
    """Reduce plot data to what Platform renders so the completion payload stays bounded for any class count.

    Platform draws the first 100 confusion matrix classes and per-class curves up to 20 classes, else only the mean.
    """
    import numpy as np

    if "matrix" in plot:  # Platform draws the first 100 classes, normalized by column totals over all rows
        return {**plot, "matrix": (m := np.array(plot["matrix"])[:, :100])[:100].tolist(), "totals": m.sum(0).tolist()}

    x, y = np.array(plot["x"]), np.array(plot["y"])
    if len(y) > 20:  # mean curve and AP only, so rows no longer map to classes
        y = y.mean(0, keepdims=True)
        plot = {k: v for k, v in plot.items() if k != "classes"}
        if "ap" in plot:
            plot["ap"] = np.mean(plot["ap"], 0, keepdims=True).tolist()
    x_new = np.linspace(x[0], x[-1], n)  # 101 points gives clean 0.01 increments
    y_new = np.array([np.interp(x_new, x, yi) for yi in y])
    return {**plot, "x": x_new.round(6).tolist(), "y": y_new.round(6).tolist()}  # Platform stores 6 decimals


def _validation_payload(image_metrics, sample_limit=5_000, extremes_limit=100):
    """Return exact F1 extremes and an evenly ranked sample for correlation analysis."""
    ranked = sorted(image_metrics.items(), key=lambda item: (item[1]["f1"], item[0]))
    if len(ranked) > sample_limit:
        sample = [ranked[round(i * (len(ranked) - 1) / (sample_limit - 1))] for i in range(sample_limit)]
    else:
        sample = ranked

    def rows(items):
        return [[Path(name).stem.split("_", 1)[0], metric["tp"], metric["fp"], metric["fn"]] for name, metric in items]

    return {
        "population": len(ranked),
        "sampling": "f1_rank",
        "rows": rows(sample),
        "extremes": {"worst": rows(ranked[:extremes_limit]), "best": rows(reversed(ranked[-extremes_limit:]))},
    }


def _sanitize_json_value(value):
    """Make payloads JSON-encodable: non-finite floats become None and other non-JSON values become strings."""
    if isinstance(value, dict):
        return {k: _sanitize_json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_json_value(v) for v in value]
    if isinstance(value, float):
        return value if isfinite(value) else None  # avoid "Out of range float values are not JSON compliant" warnings
    return value if value is None or isinstance(value, (bool, int, str)) else str(value)  # e.g. np.int64, Path


def _send(event, data, project, name, model_id=None, retry=2, timeout=30):
    """Send a training event using the SDK's retry policy."""
    global _api_key
    if not _api_key:
        return None
    import httpx

    from ultralytics import APIError, Platform

    identity = {"model_id": model_id} if model_id else {"project": project, "name": name}
    try:
        with Platform(
            api_key=_api_key,
            base_url=PLATFORM_URL,
            max_retries=retry - 1,
            retry_methods=("POST",),
            http_client=httpx.Client(follow_redirects=True),
        ) as client:
            response = client.training.metrics(
                event=event, data=_sanitize_json_value(data), timeout=timeout, **identity
            )
            return response if isinstance(response, dict) else None
    except Exception as error:
        if isinstance(error, APIError) and error.status_code == 401:
            _api_key = None
        # Console errors must not generate another console event; clearing the key makes 401 safe to log.
        if event != "console_output" or not _api_key:
            detail = f"HTTP {error.status_code}" if isinstance(error, APIError) else str(error)
            LOGGER.warning(f"{PREFIX}Failed to send {event}: {detail}")
        if event == "training_started" and model_id and isinstance(error, APIError) and error.status_code == 404:
            return {}  # {} marks a missing model, seen only by the resume lookup in on_pretrain_routine_start
        return None


def _handle_control_response(trainer, ctx, response):
    """Apply centralized stop signals returned by Platform webhook responses.

    Notes:
        ``ctx["cancelled"]`` is the durable cancellation signal. During startup, trainer setup later resets
        ``trainer.stop``, so early stop requests still rely on ``on_pretrain_routine_end()`` to reapply the flag after
        setup completes.
    """
    if response and response.get("cancelled"):
        ctx["cancelled"] = True
        trainer.stop = True
        LOGGER.info(f"{PREFIX}Training cancelled from Platform ⚠️")


def _upload_file(file_path, project, name, progress=False, retry=1, model_id=None, run_id=None, visual=False):
    """Publish a training file to its configured Platform storage location."""
    from ultralytics.utils.uploads import safe_upload

    if not _api_key:
        return None
    file_path = Path(file_path)
    if not file_path.exists():
        LOGGER.warning(f"{PREFIX}File not found: {file_path}")
        return None
    file_size = file_path.stat().st_size
    import httpx

    from ultralytics import APIError, Platform

    identity = {"model_id": model_id} if model_id else {"project": project, "name": name}
    if run_id:
        identity["run_id"] = run_id

    try:
        with Platform(
            api_key=_api_key,
            base_url=PLATFORM_URL,
            max_retries=2,
            retry_methods=("POST",),
            http_client=httpx.Client(follow_redirects=True),
        ) as client:
            data = client.models.upload_checkpoint(
                filename=file_path.name, size=file_size if visual else None, timeout=30, **identity
            )
            if not isinstance(data, dict):
                raise TypeError("Invalid Platform upload response")
    except Exception as error:
        detail = f"HTTP {error.status_code}" if isinstance(error, APIError) else str(error)
        LOGGER.warning(f"{PREFIX}Failed to get upload URL: {detail}")
        return None

    headers = {"Content-Type": "image/avif"} if visual else None
    timeout = 30 if visual else 600  # a stalled image upload must not hold the GPU at the end of training
    if safe_upload(
        file=file_path, url=data["uploadUrl"], headers=headers, retry=retry, timeout=timeout, progress=progress
    ):
        if visual:
            return file_path.name
        gcs_path = data.get("gcsPath")
        if gcs_path and run_id:
            saved = _send(
                "checkpoint_saved",
                {
                    "modelPath": gcs_path,
                    "runId": run_id,
                    "uploadPath": data.get("uploadPath"),
                },
                project,
                name,
                model_id,
                timeout=90,
            )
            return {"modelPath": gcs_path, "modelSize": file_size} if saved else None
        return {"modelPath": gcs_path, "modelSize": file_size}
    return None


def _get_environment_info():
    """Collect comprehensive environment info using existing ultralytics utilities."""
    import shutil

    import psutil
    import torch

    from ultralytics import __version__
    from ultralytics.utils.torch_utils import get_cpu_info, get_gpu_info

    # Get RAM and disk totals
    memory = psutil.virtual_memory()
    disk_usage = shutil.disk_usage("/")

    env = {
        "ultralyticsVersion": __version__,
        "hostname": socket.gethostname(),
        "os": platform.platform(),
        "environment": ENVIRONMENT,
        "pythonVersion": PYTHON_VERSION,
        "pythonExecutable": sys.executable,
        "cpuCount": os.cpu_count() or 0,
        "cpu": get_cpu_info(),
        "totalRamGb": round(memory.total / (1 << 30), 1),  # Total RAM in GB
        "totalDiskGb": round(disk_usage.total / (1 << 30), 1),  # Total disk in GB
    }

    # Git info using cached GIT singleton (no subprocess calls)
    try:
        if GIT.is_repo:
            if GIT.origin:
                env["gitRepository"] = GIT.origin
            if GIT.branch:
                env["gitBranch"] = GIT.branch
            if GIT.commit:
                env["gitCommit"] = GIT.commit[:12]  # Short hash
            if GIT.message:
                env["gitCommitMessage"] = GIT.message
    except Exception:
        pass

    # GPU info
    try:
        if torch.cuda.is_available():
            env["gpuCount"] = torch.cuda.device_count()
            env["gpuType"] = get_gpu_info(0) if torch.cuda.device_count() > 0 else None
    except Exception:
        pass

    return env


def _get_project_name(trainer):
    """Get slugified project and raw run name from trainer args; Platform derives the model slug from the name.

    A local save directory names the project by its last folder with a usable name, so a path never becomes a Platform
    project name.
    """
    raw = str(trainer.args.project)
    path = PureWindowsPath(raw)  # reads both separators and drive letters on any OS
    if path.anchor or raw.startswith(("~", ".")) or "\\" in raw:  # a local path, not `username/project`
        raw = next((part for part in reversed(path.parts) if slugify(part)), raw)
    parts = raw.split("/", 1)
    project = f"{parts[0]}/{slugify(parts[1].replace('/', '-'))}" if len(parts) == 2 else slugify(raw)
    return project, str(trainer.args.name or "train")


def _get_training_gpus(trainer):
    """Return the NVML indices of the GPUs a run trains on, so a shared host reports no other runs' GPUs.

    Trainer CUDA indices are torch indices, which map to NVML ids through CUDA_VISIBLE_DEVICES. Non-CUDA training
    reports no GPUs, and a CUDA_VISIBLE_DEVICES of GPU UUIDs, which has no index mapping, reports every GPU.
    """
    if trainer.device.type != "cuda":
        return []
    indices = [int(x) for x in trainer.args.device.split(",") if x.isdigit()] or [trainer.device.index]
    visible = [x for x in os.environ.get("CUDA_VISIBLE_DEVICES", "").replace(" ", "").split(",") if x]
    if not visible:
        return indices
    ids = [visible[i] for i in indices]
    return [int(x) for x in ids] if all(x.isdigit() for x in ids) else None


def _get_system_metrics(trainer):
    """Sample the run's system logger without making optional host monitoring a training dependency."""
    ctx = trainer.platform
    try:
        if not ctx["system_logger"]:
            from ultralytics.utils.logger import SystemLogger

            ctx["system_logger"] = SystemLogger(all_drives=True, gpus=_get_training_gpus(trainer))
        return ctx["system_logger"].get_metrics(rates=True)
    except Exception:
        return None


def on_pretrain_routine_start(trainer):
    """Initialize Platform logging at training start, continuing the recorded Platform model when resuming."""
    global _api_key
    if TESTS_RUNNING or not trainer.args.project:
        return
    _api_key = os.getenv("ULTRALYTICS_API_KEY") or SETTINGS.get("api_key")
    if not _api_key:
        return
    if sys.version_info < (3, 11):
        LOGGER.warning(
            f"{PREFIX}Platform integration requires Python 3.11 or newer. Training will continue without tracking."
        )
        return

    project, name = _get_project_name(trainer)
    LOGGER.info(f"{PREFIX}Streaming training metrics to Platform")

    from ultralytics.utils.logger import ConsoleLogger

    # Single dict for all platform callback state
    ctx = {
        "model_id": None,
        "run_id": None,
        "last_upload": time(),
        "checkpoint_upload": None,
        "visual_upload": None,
        "cancelled": False,
        "console_logger": None,
        "system_logger": None,
    }
    trainer.platform = ctx

    # Create callback to send console output to Platform
    def send_console_output(content, line_count, chunk_id):
        """Send batched console output and live progress bar frames to Platform webhook."""
        _executor.submit(
            _send,
            "console_output",
            {
                "chunkId": chunk_id,
                "content": content,
                "lineCount": line_count,
                "progress": ctx["console_logger"].progress_sent,
            },
            project,
            name,
            ctx["model_id"],
        )

    # Console capture with batching (5 lines or 5 seconds). Built here, but not started until Platform
    # has accepted the run below: capturing first left the user's stdout redirected through a dead
    # integration whenever training_started failed, and its final flush would post a console chunk
    # carrying no model_id.
    ctx["console_logger"] = ConsoleLogger(batch_size=5, flush_interval=5.0, on_flush=send_console_output)

    # Collect environment info (W&B-style metadata)
    environment = _get_environment_info()

    # Build trainArgs - callback runs before get_dataset() so args.data is still original (e.g., ul:// URIs)
    # Note: model_info is sent later in on_fit_epoch_end (epoch 0) when the model is actually loaded
    data = {
        "trainArgs": vars(trainer.args),  # _send makes values JSON-encodable
        "epochs": trainer.epochs,
        "device": str(trainer.device),
        "environment": environment,
        "system": _get_system_metrics(trainer),
    }
    record = Path(trainer.save_dir) / "platform_model_id.txt"  # resume continues the Platform model recorded here
    model_id = record.read_text() if trainer.args.resume and record.exists() else None

    # Send synchronously to get modelId for subsequent webhooks (critical, more retries)
    response = _send("training_started", data, project, name, model_id=model_id, retry=4)
    if model_id and (response == {} or (response and response.get("cancelled"))):  # model gone or ended, track as new
        response = _send("training_started", data, project, name, retry=4)
    if response and response.get("modelId"):
        record.write_text(response["modelId"])
        ctx["model_id"] = response["modelId"]
        ctx["run_id"] = response.get("runId")
        # Server resolves the owner, project and final slug (e.g. "train" → "train-2") into the model link
        ctx["model_url"] = response.get("modelUrl")
        if ctx["model_url"]:
            LOGGER.info(f"{PREFIX}View model at {ctx['model_url']}")
        ctx["console_logger"].start_capture()  # only now: the run is tracked and model_id is known
        # Note: trainer.stop is set in on_pretrain_routine_end (after _setup_train resets it)
        _handle_control_response(trainer, ctx, response)
    else:
        LOGGER.warning(f"{PREFIX}Training will not be tracked on Platform")
        trainer.platform = None  # Disable further callbacks


def on_pretrain_routine_end(trainer):
    """Apply pre-start cancellation after _setup_train resets trainer.stop."""
    ctx = getattr(trainer, "platform", None)
    if ctx and ctx["cancelled"]:
        LOGGER.info(f"{PREFIX}Training cancelled from Platform before starting ✅")
        trainer.stop = True


def on_fit_epoch_end(trainer):
    """Log training and system metrics at epoch end."""
    ctx = getattr(trainer, "platform", None)
    if not ctx:
        return

    project, name = _get_project_name(trainer)
    metrics = {**trainer.label_loss_items(trainer.tloss, prefix="train"), **trainer.metrics}
    first_epoch = trainer.epoch == 0
    # Initial training batch plots, listed here because plotting threads may still be adding to trainer.plots
    visual_files = (
        [p for i in range(3) if (p := trainer.save_dir / f"train_batch{i}.jpg") in trainer.plots]
        if first_epoch and ctx["run_id"]
        else []
    )

    if trainer.optimizer and trainer.optimizer.param_groups:
        metrics["lr"] = trainer.optimizer.param_groups[0]["lr"]

    # Extract model info at epoch 0 (sent as separate field, not in metrics)
    model_info = None
    if first_epoch:
        try:
            from ultralytics.utils.torch_utils import model_info_for_loggers

            info = model_info_for_loggers(trainer)
            model_info = {
                "parameters": info.get("model/parameters", 0),
                "gflops": info.get("model/GFLOPs", 0),
                "speedMs": info.get("model/speed_PyTorch(ms)", 0),
            }
        except Exception:
            pass

    payload = {
        "epoch": trainer.epoch,
        "metrics": metrics,
        "system": _get_system_metrics(trainer),
        "fitness": trainer.fitness,
        "best_fitness": trainer.best_fitness,
    }
    if model_info:
        payload["modelInfo"] = model_info

    def _send_and_check_cancel():
        """Send epoch_end and check response for cancellation (runs in background thread)."""
        if visual_files:
            try:
                from PIL import Image

                with tempfile.TemporaryDirectory() as tmp:
                    visuals = []
                    for f in visual_files:
                        avif = Path(tmp) / f"{f.stem}.avif"
                        with Image.open(f) as im:
                            im.save(avif, "AVIF", quality=70)  # Platform image standard, needs Pillow>=11.3
                        if _upload_file(
                            avif, project, name, model_id=ctx["model_id"], run_id=ctx["run_id"], visual=True
                        ):
                            visuals.append(avif.name)
                if visuals:
                    payload["visuals"] = visuals
            except Exception as e:  # optional visuals never block epoch metrics or the end of training
                LOGGER.warning(f"{PREFIX}Training visuals not uploaded: {e}")
        response = _send("epoch_end", payload, project, name, ctx["model_id"], retry=1)
        _handle_control_response(trainer, ctx, response)

    upload = _executor.submit(_send_and_check_cancel)
    if first_epoch:
        ctx["visual_upload"] = upload


def on_model_save(trainer):
    """Upload model checkpoint (rate limited to every 15 min)."""
    ctx = getattr(trainer, "platform", None)
    if not ctx:
        return
    # Rate limit to every 15 minutes (900 seconds)
    if time() - ctx["last_upload"] < 900:
        return
    if ctx["checkpoint_upload"] and not ctx["checkpoint_upload"].done():
        return

    model_path = trainer.best if trainer.best and Path(trainer.best).exists() else trainer.last
    if not model_path:
        return

    project, name = _get_project_name(trainer)
    ctx["checkpoint_upload"] = _executor.submit(
        _upload_file, model_path, project, name, model_id=ctx["model_id"], run_id=ctx["run_id"]
    )
    ctx["last_upload"] = time()


def on_train_end(trainer):
    """Log final training results and upload the best model to Platform."""
    ctx = getattr(trainer, "platform", None)  # set only by on_pretrain_routine_start, so unset without an API key
    if not ctx:
        return

    project, name = _get_project_name(trainer)

    if ctx["cancelled"]:
        LOGGER.info(f"{PREFIX}Uploading partial results for cancelled training")

    # Stop console capture
    ctx["console_logger"].stop_capture()
    if ctx["visual_upload"]:
        ctx["visual_upload"].result()

    # Upload best.pt, or last.pt when save=False never wrote best.pt (blocking with progress bar to ensure it completes)
    artifact = None
    model_path = trainer.best if trainer.best and Path(trainer.best).exists() else trainer.last
    if Path(model_path).exists():
        if ctx["checkpoint_upload"]:
            ctx["checkpoint_upload"].result()
        artifact = _upload_file(
            model_path,
            project,
            name,
            progress=True,
            retry=3,
            model_id=ctx["model_id"],
            run_id=ctx["run_id"],
        )
        if not artifact:
            LOGGER.warning(f"{PREFIX}Model will not be available for download on Platform (upload failed)")

    # Collect plots from trainer and validator, deduplicating by type
    plots_by_type = {}
    for info in getattr(trainer, "plots", {}).values():
        if info.get("data") and info["data"].get("type"):
            plots_by_type[info["data"]["type"]] = info["data"]
    for info in reversed(getattr(getattr(trainer, "validator", None), "plots", {}).values()):
        if info.get("data") and info["data"].get("type"):
            plots_by_type.setdefault(info["data"]["type"], info["data"])  # Don't overwrite trainer plots
    # Curve rows only cover classes with val labels: send their model class indices when any class is missing
    if pr := plots_by_type.get("pr_curve"):
        classes = [int(c) for c in trainer.validator.metrics.ap_class_index]
        if len(classes) < len(trainer.validator.names):
            plots_by_type["pr_curve"] = {**pr, "classes": classes}
    plots = [_compact_plot(p) for p in plots_by_type.values()]

    # Get class names
    names = getattr(getattr(trainer, "validator", None), "names", None) or (trainer.data or {}).get("names")
    class_names = list(names.values()) if isinstance(names, dict) else list(names) if names else None

    # stopper.best_epoch is 1-indexed; -1 aligns with the 0-indexed `epoch` field
    best_epoch = max(0, getattr(getattr(trainer, "stopper", None), "best_epoch", trainer.epoch + 1) - 1)

    image_metrics = trainer.validator.metrics.box.image_metrics if trainer.args.task == "detect" else {}
    validation = _validation_payload(image_metrics)
    _send(
        "training_complete",
        {
            "results": {
                "metrics": {**trainer.metrics, "fitness": trainer.fitness},
                "bestEpoch": best_epoch,
                "bestFitness": trainer.best_fitness,
                **({"calibration": c} if (c := getattr(trainer, "depth_calibration", None)) else {}),
                **({"validation": validation} if validation["rows"] else {}),
                **(artifact or {}),
            },
            "classNames": class_names,
            "plots": plots,
            "runId": ctx["run_id"],
        },
        project,
        name,
        ctx["model_id"],
        retry=4,  # Critical, more retries
    )
    if ctx.get("model_url"):
        LOGGER.info(f"{PREFIX}View results at {ctx['model_url']}")


callbacks = {
    "on_pretrain_routine_start": on_pretrain_routine_start,
    "on_pretrain_routine_end": on_pretrain_routine_end,
    "on_fit_epoch_end": on_fit_epoch_end,
    "on_model_save": on_model_save,
    "on_train_end": on_train_end,
    "teardown": lambda trainer: (ctx := getattr(trainer, "platform", None)) and ctx["console_logger"].stop_capture(),
}
