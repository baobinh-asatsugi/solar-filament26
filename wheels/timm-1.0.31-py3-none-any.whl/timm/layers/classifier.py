""" Classifier head and layer factory

Hacked together by / Copyright 2020 Ross Wightman
"""
from collections import OrderedDict
from functools import partial
from typing import Optional, Union, Callable

import torch
import torch.nn as nn
from torch.nn import functional as F

from .adaptive_avgmax_pool import SelectAdaptivePool2d
from .create_act import get_act_layer
from .create_norm import get_norm_layer
from .helpers import get_device_dtype


def _create_pool(
        num_features: int,
        num_classes: int,
        pool_type: str = 'avg',
        use_conv: bool = False,
        input_fmt: Optional[str] = None,
):
    flatten_in_pool = not use_conv  # flatten when we use a Linear layer after pooling
    if not pool_type:
        flatten_in_pool = False  # disable flattening if pooling is pass-through (no pooling)
    global_pool = SelectAdaptivePool2d(
        pool_type=pool_type,
        flatten=flatten_in_pool,
        input_fmt=input_fmt,
    )
    num_pooled_features = num_features * global_pool.feat_mult()
    return global_pool, num_pooled_features


def _create_fc(num_features, num_classes, use_conv=False, device=None, dtype=None):
    if num_classes <= 0:
        fc = nn.Identity()  # pass-through (no classifier)
    elif use_conv:
        fc = nn.Conv2d(num_features, num_classes, 1, bias=True, device=device, dtype=dtype)
    else:
        fc = nn.Linear(num_features, num_classes, bias=True, device=device, dtype=dtype)
    return fc


def create_classifier(
        num_features: int,
        num_classes: int,
        pool_type: str = 'avg',
        use_conv: bool = False,
        input_fmt: str = 'NCHW',
        drop_rate: Optional[float] = None,
        device=None,
        dtype=None,
):
    global_pool, num_pooled_features = _create_pool(
        num_features,
        num_classes,
        pool_type,
        use_conv=use_conv,
        input_fmt=input_fmt,
    )
    fc = _create_fc(
        num_pooled_features,
        num_classes,
        use_conv=use_conv,
        device=device,
        dtype=dtype,
    )
    if drop_rate is not None:
        dropout = nn.Dropout(drop_rate)
        return global_pool, dropout, fc
    return global_pool, fc


class ClassifierHead(nn.Module):
    """Classifier head w/ configurable global pooling and dropout."""

    def __init__(
            self,
            in_features: int,
            num_classes: int,
            pool_type: str = 'avg',
            drop_rate: float = 0.,
            use_conv: bool = False,
            input_fmt: str = 'NCHW',
            device=None,
            dtype=None,
    ):
        """
        Args:
            in_features: The number of input features.
            num_classes:  The number of classes for the final classifier layer (output).
            pool_type: Global pooling type, pooling disabled if empty string ('').
            drop_rate: Pre-classifier dropout rate.
        """
        super().__init__()
        self.in_features = in_features
        self.use_conv = use_conv
        self.input_fmt = input_fmt

        global_pool, fc = create_classifier(
            in_features,
            num_classes,
            pool_type,
            use_conv=use_conv,
            input_fmt=input_fmt,
            device=device,
            dtype=dtype,
        )
        self.global_pool = global_pool
        self.num_features = in_features * global_pool.feat_mult()  # pooled (pre-logits) width
        self.drop = nn.Dropout(drop_rate)
        self.fc = fc
        self.flatten = nn.Flatten(1) if use_conv and pool_type else nn.Identity()

    def reset(
            self,
            num_classes: int,
            pool_type: Optional[str] = None,
            reset_other: bool = False,
            in_features: Optional[int] = None,
            device=None,
            dtype=None,
    ):
        """
        Args:
            num_classes: The number of classes for the new classifier, 0 to remove it.
            pool_type: New global pooling type, unchanged if None.
            reset_other: No-op, there are no layers other than the pooling and classifier (for head API parity).
            in_features: New number of input features, e.g. after pruning the layers feeding the head.
        """
        dd = get_device_dtype(self, device=device, dtype=dtype)
        if in_features is not None:
            self.in_features = in_features
        if pool_type is not None and pool_type != self.global_pool.pool_type:
            self.global_pool, self.fc = create_classifier(
                self.in_features,
                num_classes,
                pool_type=pool_type,
                use_conv=self.use_conv,
                input_fmt=self.input_fmt,
                **dd,
            )
            self.global_pool.train(self.training)
            self.fc.train(self.training)
            self.flatten = nn.Flatten(1) if self.use_conv and pool_type else nn.Identity()
            self.flatten.train(self.training)
        else:
            num_pooled_features = self.in_features * self.global_pool.feat_mult()
            self.fc = _create_fc(
                num_pooled_features,
                num_classes,
                use_conv=self.use_conv,
                **dd,
            )
            self.fc.train(self.training)
        self.num_features = self.in_features * self.global_pool.feat_mult()

    def forward(self, x, pre_logits: bool = False):
        x = self.global_pool(x)
        x = self.drop(x)
        if pre_logits:
            return self.flatten(x)
        x = self.fc(x)
        return self.flatten(x)


class NormMlpClassifierHead(nn.Module):
    """ A Pool -> Norm -> Mlp Classifier Head for '2D' NCHW tensors
    """
    def __init__(
            self,
            in_features: int,
            num_classes: int,
            hidden_size: Optional[int] = None,
            pool_type: str = 'avg',
            drop_rate: float = 0.,
            norm_layer: Union[str, Callable] = 'layernorm2d',
            act_layer: Union[str, Callable] = 'tanh',
            device=None,
            dtype=None
    ):
        """
        Args:
            in_features: The number of input features.
            num_classes:  The number of classes for the final classifier layer (output).
            hidden_size: The hidden size of the MLP (pre-logits FC layer) if not None.
            pool_type: Global pooling type, pooling disabled if empty string ('').
            drop_rate: Pre-classifier dropout rate.
            norm_layer: Normalization layer type.
            act_layer: MLP activation layer type (only used if hidden_size is not None).
        """
        dd = {'device': device, 'dtype': dtype}
        super().__init__()
        self.in_features = in_features
        self.hidden_size = hidden_size
        self.num_features = in_features
        self.use_conv = not pool_type
        norm_layer = get_norm_layer(norm_layer)
        act_layer = get_act_layer(act_layer)
        linear_layer = partial(nn.Conv2d, kernel_size=1) if self.use_conv else nn.Linear

        self.global_pool = SelectAdaptivePool2d(pool_type=pool_type)
        assert self.global_pool.feat_mult() == 1, 'Pooling that changes the pooled width is not supported.'
        self.norm = norm_layer(in_features, **dd)
        self.flatten = nn.Flatten(1) if pool_type else nn.Identity()
        if hidden_size:
            self.pre_logits = nn.Sequential(OrderedDict([
                ('fc', linear_layer(in_features, hidden_size, **dd)),
                ('act', act_layer()),
            ]))
            self.num_features = hidden_size
        else:
            self.pre_logits = nn.Identity()
        self.drop = nn.Dropout(drop_rate)
        self.fc = linear_layer(self.num_features, num_classes, **dd) if num_classes > 0 else nn.Identity()

    def reset(
            self,
            num_classes: int,
            pool_type: Optional[str] = None,
            reset_other: bool = False,
            in_features: Optional[int] = None,
            device=None,
            dtype=None,
    ):
        dd = get_device_dtype(self, device=device, dtype=dtype)
        if in_features is not None and in_features != self.in_features:
            assert reset_other or isinstance(self.norm, nn.Identity), \
                'Input features can only change w/ norm removed (reset_other).'
        if pool_type is not None:
            global_pool = SelectAdaptivePool2d(pool_type=pool_type)
            assert global_pool.feat_mult() == 1, 'Pooling that changes the pooled width is not supported.'
            self.global_pool = global_pool.train(self.training)
            self.flatten = nn.Flatten(1) if pool_type else nn.Identity()
            self.flatten.train(self.training)
        if reset_other:
            # remove the norm and pre-logits, leaving pooling and the classifier
            self.norm = nn.Identity().train(self.training)
            self.pre_logits = nn.Identity().train(self.training)
            self.hidden_size = None
            self.num_features = self.in_features
        if in_features is not None and in_features != self.in_features:
            self.in_features = in_features
            if not self.hidden_size:
                self.num_features = in_features
        self.use_conv = self.global_pool.is_identity()
        linear_layer = partial(nn.Conv2d, kernel_size=1) if self.use_conv else nn.Linear
        if self.hidden_size:
            if ((isinstance(self.pre_logits.fc, nn.Conv2d) and not self.use_conv) or
                    (isinstance(self.pre_logits.fc, nn.Linear) and self.use_conv)):
                with torch.no_grad():
                    new_fc = linear_layer(self.in_features, self.hidden_size, **dd)
                    new_fc.weight.copy_(self.pre_logits.fc.weight.reshape(new_fc.weight.shape))
                    new_fc.weight.requires_grad_(self.pre_logits.fc.weight.requires_grad)
                    new_fc.bias.copy_(self.pre_logits.fc.bias)
                    new_fc.bias.requires_grad_(self.pre_logits.fc.bias.requires_grad)
                    self.pre_logits.fc = new_fc
                    self.pre_logits.fc.train(self.pre_logits.training)
        self.fc = linear_layer(self.num_features, num_classes, **dd) if num_classes > 0 else nn.Identity()
        self.fc.train(self.training)

    def forward(self, x, pre_logits: bool = False):
        x = self.global_pool(x)
        x = self.norm(x)
        x = self.flatten(x)
        x = self.pre_logits(x)
        x = self.drop(x)
        if pre_logits:
            return x
        x = self.fc(x)
        return x


class ClNormMlpClassifierHead(nn.Module):
    """ A Pool -> Norm -> Mlp Classifier Head for n-D NxxC tensors
    """
    def __init__(
            self,
            in_features: int,
            num_classes: int,
            hidden_size: Optional[int] = None,
            pool_type: str = 'avg',
            drop_rate: float = 0.,
            norm_layer: Union[str, Callable] = 'layernorm',
            act_layer: Union[str, Callable] = 'gelu',
            input_fmt: str = 'NHWC',
            device=None,
            dtype=None,
    ):
        """
        Args:
            in_features: The number of input features.
            num_classes:  The number of classes for the final classifier layer (output).
            hidden_size: The hidden size of the MLP (pre-logits FC layer) if not None.
            pool_type: Global pooling type, pooling disabled if empty string ('').
            drop_rate: Pre-classifier dropout rate.
            norm_layer: Normalization layer type.
            act_layer: MLP activation layer type (only used if hidden_size is not None).
        """
        dd = {'device': device, 'dtype': dtype}
        super().__init__()
        self.in_features = in_features
        self.hidden_size = hidden_size
        self.num_features = in_features
        assert pool_type in ('', 'avg', 'max', 'avgmax'), 'Only avg, max or avgmax pooling (or none) is supported.'
        self.pool_type = pool_type
        assert input_fmt in ('NHWC', 'NLC')
        self.pool_dim = 1 if input_fmt == 'NLC' else (1, 2)
        norm_layer = get_norm_layer(norm_layer)
        act_layer = get_act_layer(act_layer)

        self.norm = norm_layer(in_features, **dd)
        if hidden_size:
            self.pre_logits = nn.Sequential(OrderedDict([
                ('fc', nn.Linear(in_features, hidden_size, **dd)),
                ('act', act_layer()),
            ]))
            self.num_features = hidden_size
        else:
            self.pre_logits = nn.Identity()
        self.drop = nn.Dropout(drop_rate)
        self.fc = nn.Linear(self.num_features, num_classes, **dd) if num_classes > 0 else nn.Identity()

    def reset(
            self,
            num_classes: int,
            pool_type: Optional[str] = None,
            reset_other: bool = False,
            in_features: Optional[int] = None,
            device=None,
            dtype=None,
    ):
        dd = get_device_dtype(self, device=device, dtype=dtype)
        if pool_type is not None:
            assert pool_type in ('', 'avg', 'max', 'avgmax'), 'Only avg, max or avgmax pooling (or none) is supported.'
            self.pool_type = pool_type
        if reset_other:
            self.pre_logits = nn.Identity()
            self.pre_logits.train(self.training)
            self.norm = nn.Identity()
            self.norm.train(self.training)
            self.hidden_size = None
            self.num_features = self.in_features
        if in_features is not None and in_features != self.in_features:
            assert isinstance(self.norm, nn.Identity), 'Input features can only change w/ norm removed (reset_other).'
            self.in_features = in_features
            if not self.hidden_size:
                self.num_features = in_features
        self.fc = nn.Linear(self.num_features, num_classes, **dd) if num_classes > 0 else nn.Identity()
        self.fc.train(self.training)

    def _global_pool(self, x):
        if self.pool_type:
            if self.pool_type == 'avg':
                x = x.mean(dim=self.pool_dim)
            elif self.pool_type == 'max':
                x = x.amax(dim=self.pool_dim)
            elif self.pool_type == 'avgmax':
                x = 0.5 * (x.amax(dim=self.pool_dim) + x.mean(dim=self.pool_dim))
        return x

    def forward(self, x, pre_logits: bool = False):
        x = self._global_pool(x)
        x = self.norm(x)
        x = self.pre_logits(x)
        x = self.drop(x)
        if pre_logits:
            return x
        x = self.fc(x)
        return x
